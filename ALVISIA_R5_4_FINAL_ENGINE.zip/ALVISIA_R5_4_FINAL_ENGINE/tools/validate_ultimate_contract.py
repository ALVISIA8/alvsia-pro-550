#!/usr/bin/env python3
"""R5.4 Ultimate API contract check.

Checks the exact API names used by the bridge against the compatibility layer
and, when supplied, reports whether the legacy reference has the same names.
The protected module is intentionally not imported during a static build check.
"""
from __future__ import annotations
import ast, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = ROOT / "app/src/main/python/alvsia_bridge.py"
COMPAT = ROOT / "app/src/main/python/alvsia_ultimate_compat.py"
REFERENCE = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT.parent / "UltimateEngineTool.py"

bridge = BRIDGE.read_text(encoding="utf-8", errors="ignore")
compat_tree = ast.parse(COMPAT.read_text(encoding="utf-8", errors="ignore"))
compat_funcs = {n.name for n in ast.walk(compat_tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}

# Bridge uses _ult_call('name', ...) so the API surface is explicit and easy to audit.
calls = sorted(set(re.findall(r"_ult_call\(\s*['\"]([A-Za-z_][A-Za-z0-9_]*)['\"]", bridge)))
missing_compat = [x for x in calls if x not in compat_funcs]

ref_funcs = set()
if REFERENCE.is_file():
    ref_tree = ast.parse(REFERENCE.read_text(encoding="utf-8", errors="ignore"))
    ref_funcs = {n.name for n in ast.walk(ref_tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}

print(f"bridge ultimate API calls: {len(calls)}")
print(f"compat API functions:      {len(compat_funcs)}")
print(f"reference functions:       {len(ref_funcs) if ref_funcs else 'N/A'}")
for x in calls:
    compat = x in compat_funcs
    ref = x in ref_funcs if ref_funcs else None
    suffix = "compat=OK" if compat else "compat=MISSING"
    if ref is not None:
        suffix += ", reference=" + ("OK" if ref else "legacy-missing")
    print(f"{('OK   ' if compat else 'MISS ')} {x} [{suffix}]")

ok = not missing_compat and len(calls) == 31
print("RESULT:", "PASS (31/31 bridge APIs have concrete implementations)" if ok else f"FAIL ({len(missing_compat)} compat APIs missing)")
raise SystemExit(0 if ok else 1)

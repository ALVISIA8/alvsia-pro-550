# ALVISIA PRO 5.5.0 — Build Steps, Limitations & Backend Requirements

**Date:** 2026-10-11

---

## Build Steps

### Prerequisites
- Android Studio Hedgehog or later (Gradle 8.x)
- NDK 27.0.12077973 (set in `app/build.gradle.kts` → `ndkVersion`)
- CMake 3.22.1+
- Python 3.9+ with `cryptography` package: `pip install cryptography`
- Java 17
- (Release only) Release keystore + signing credentials

### Local Debug Build
```bash
./gradlew assembleDebug
# Output: app/build/outputs/apk/debug/app-debug.apk
# Note: No sealing, no R8, no AndResGuard in debug mode.
```

### Local Release Build
```bash
# Step 1: Generate per-build seal seed
export ALVSIA_SEAL_SEED_HEX=$(python3 -c 'import secrets; print(secrets.token_hex(32))')

# Step 2: Set signing credentials
export CM_KEYSTORE_PATH=/path/to/your/release.keystore
export CM_KEYSTORE_PASSWORD=your_keystore_password
export CM_KEY_ALIAS=alvsia
export CM_KEY_PASSWORD=your_key_password

# Step 3: Build (sealPython task runs automatically before compile)
./gradlew assembleRelease

# Step 4: Python sources are automatically restored after build
# Output: app/build/outputs/apk/release/app-release.apk
```

### CodeMagic CI Build
The `codemagic.yaml` handles:
1. Branch enforcement (main branch only)
2. Android SDK setup
3. Signing secret validation (CM_KEYSTORE, CM_KEYSTORE_PASSWORD, CM_KEY_ALIAS=alvsia, CM_KEY_PASSWORD)
4. Automatic per-build seed: `ALVSIA_SEAL_SEED_HEX=$(python3 -c 'import secrets; print(secrets.token_hex(32))')`
5. Python sealing via Gradle task (new — wired in this session)
6. Regression tests (test_lua_engine, test_bgmi_transform, test_pak_extraction, test_tool_dispatch, test_vanta_redteam)

### Signing
Application ID: `com.alvsia.pro`  
Key alias: `alvsia`  
Certificate SHA-256 (expected): `99b33815c88a17abbcfe22be15250363f6dfc79c11ffc980e71b62b74b1f295c`

**NEVER commit the keystore, keystore password, or ALVSIA_SEAL_SEED_HEX to the repository.**  
Use environment variables or CodeMagic secret management only.

---

## Package & Signature Verification (Post-Build)

```bash
# Verify package ID
aapt dump badging app-release.apk | grep package

# Verify APK signature
apksigner verify --verbose --print-certs app-release.apk

# Get certificate SHA-256
keytool -printcert -jarfile app-release.apk | grep SHA256

# Get APK SHA-256
sha256sum app-release.apk
```

Expected values:
- `package: name='com.alvsia.pro'`
- `versionName='5.5.0-upgrade'`
- `versionCode='96'`
- Certificate SHA-256: `99b33815c88a17abbcfe22be15250363f6dfc79c11ffc980e71b62b74b1f295c`

---

## Known Limitations

### Build Limitations
1. **ALVSIA_SEAL_SEED_HEX required for release** — The Gradle sealPython task enforces this. Local builds that skip this env var will fail at the GradleException check. This is intentional.
2. **FLAG_HW_BREAKPOINT stubbed** — `rasp_guard.cpp` bit 3 always returns 0. Hardware breakpoint registers (ARM64 MDSCR_EL1) require kernel-level access not available from user-space NDK code.
3. **Backup SPKI pin absent** — Only one cert pin (`alvsiapro.cc.cd`). If the server certificate rotates without an APK update, the app will lose network access. Add a backup pin in `Vault.kt` before broad release.
4. **Python 3.8 only** — Chaquopy is pinned to Python 3.8. Some modern cryptography library features require 3.9+. This is a Chaquopy compatibility constraint.

### Security Limitations
5. **Sealed module runtime** — Once a module is decrypted in memory, a sophisticated runtime attacker with Frida or GDB can extract it. The sealing protects the file-at-rest and distribution, not in-memory content. RASP attempts to detect instrumentation before decryption, but timing windows exist.
6. **Server-side enforcement not audited** — HWID binding, OTP single-use enforcement, session revocation, and operation authorization are backend responsibilities. No backend source was available for audit. The APK-side contracts are implemented correctly; backend conformance is assumed.
7. **RamToolVault wipe is best-effort** — `ByteArray.fill(0)` is a JVM operation. The JIT compiler may optimize it away or the GC may have already relocated the buffer. The native wipe (`nativeWipe`) calls memset but faces the same caveat for JVM-managed buffers.
8. **Frida Tracer tool (Tool 11) generates scripts only** — Actual Frida invocation requires the Frida server running on the device. This tool is for generating hook scripts for offline use, not live tracing from within the app.
9. **ZUC cipher in Decrypt Engine (Tool 13) is approximate** — The ZUC stream cipher implementation in `decrypt_auto()` is a heuristic approximation, not a standards-conformant implementation. Do not rely on it for correctness against production ZUC-encrypted data.

### On-Device Testing
10. **No on-device smoke test performed** — This environment has no connected Android device. All tool function tests are NOT TESTED at the device level. The codemagic.yaml regression tests cover lua_engine, bgmi_transform, pak_extraction, tool_dispatch, and vanta_redteam statically.

---

## Backend Requirements

The following server-side endpoints and behaviors are required for full Layer 7 operation. These must be implemented and maintained by the panel backend:

| Endpoint | Purpose | Required Behavior |
|----------|---------|------------------|
| GET `/v1/captcha` | Login challenge | Returns mechanic + PoW prefix/difficulty |
| POST `/v1/connect` | Login + token issue | Validates key + HWID; issues 64-hex session token |
| POST `/v1/otp` | OTP verification | Single-use OTP; returns confirmed session |
| POST `/v1/fetch` | Tool operation grant | Validates session token + HWID + operation type |
| POST `/v1/sec` | Threat reporting | Receives ThreatReport events; no client response required |
| GET `/v1/loader-key` | Sealed loader key | Returns per-session loader key material |

**Security requirements for the backend:**
- HWID must be stored and verified per license key
- Session tokens must be single-device: same key on different HWID must fail or trigger re-auth
- OTP codes must be single-use with short TTL (≤5 minutes recommended)
- `/v1/fetch` must validate that the requested operation is permitted for the session's license tier
- All endpoints must enforce HTTPS; the client pins the SPKI so the backend cert must match the pinned digest

---

## Change Log (This Session)

| File | Change | Reason |
|------|--------|--------|
| `app/src/main/java/com/alvsia/pro/asset/AssetVault.kt` | Removed hardcoded cert fallback `"99b33815..."` from `key()`. Added `SecurityException` propagation in `loadSealedMap()`. | Fallback allowed asset decryption on tampered APK with no valid signing cert. Now fails secure. |
| `app/src/main/java/com/alvsia/pro/sec/NativeGuard.kt` | Added `buildId` format validation (`[A-Za-z0-9_\-.]`, max 128 chars) and 32MB payload size cap in `decryptSealedPayload()`. | JNI boundary validation: prevents malformed input from reaching native seed extraction. |
| `app/src/main/java/com/alvsia/pro/sec/SessionGate.kt` | Added `synchronized(this)` guard for `_appCtx` initialization in `allowTools()` and `unlock()`. | Race condition: `sessionOk` could read null `_appCtx` if two threads entered simultaneously on first call. |
| `app/src/main/java/com/alvsia/pro/tool/ToolEngine.kt` | Added `AtomicLong _opSequence` + `ConcurrentHashMap _lastGrantNonce` for per-session monotonic anti-replay. | Prevents in-process operation grant replay within a session. |
| `app/build.gradle.kts` | Added `sealPython` and `restorePython` Gradle tasks wired to release build lifecycle. | Python sealing was not integrated into Gradle — required manual invocation. Now automated. |


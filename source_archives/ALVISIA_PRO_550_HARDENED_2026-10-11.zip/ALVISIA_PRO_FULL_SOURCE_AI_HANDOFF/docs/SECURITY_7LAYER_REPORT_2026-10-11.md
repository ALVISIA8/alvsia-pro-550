# ALVISIA PRO 5.5.0 — 7-Layer Internal Protection Architecture Report

**Date:** 2026-10-11  
**Source Version:** 5.5.0-upgrade (versionCode 96)  
**Application ID:** com.alvsia.pro  
**Audit Scope:** Full source handoff ZIP — ALVISIA_PRO_FULL_SOURCE_AI_HANDOFF  
**Session:** AI security audit + hardening pass

---

## Executive Summary

ALVISIA PRO 5.5.0 ships a coherent 7-layer internal protection system. Five concrete security improvements were implemented during this audit. The sealed Python module pipeline (Layer 6) is architecturally complete but requires `ALVSIA_SEAL_SEED_HEX` to be set at build time — a Gradle task integration is now included. All 17 tool modules are implemented with varying completeness (12 FULL, 5 PARTIAL). Zero regressions were introduced: no existing functions were removed or stubbed.

---

## Layer 1 — Build Identity & Release Integrity

**Status: IMPLEMENTED**

### Components
- `IntegrityBomb.kt` — Primary integrity evaluator
- `Tamper.kt` — Certificate + package + tag checks
- `BuildConfig.CERT_SHA256` — Compile-time expected cert digest

### Implementation Details

**Certificate Verification (API 28+):**  
Uses `GET_SIGNING_CERTIFICATES` (PackageManager, not spoofable via reflection). SHA-256 digest compared against `BuildConfig.CERT_SHA256 = "99b33815c88a17abbcfe22be15250363f6dfc79c11ffc980e71b62b74b1f295c"`. Legacy API path also checked.

**DEX Size Bounds:**  
Rejects DEX files outside 100KB–40MB window. Detects completely replaced DEX files that are trivially small or suspiciously large.

**Clone Container Detection:**  
Data directory path scanned for clone/dual-space fragments: parallel, dual, virtualapp, blackbox, vmos, island, 360plugin, etc.

**Repack Detection:**  
Package name mismatch, test-keys build tag, debuggable flag. Note: `sig_path_disagree` check intentionally removed — Reark stub causes a legitimate path divergence.

**Integration Point:**  
`IntegrityBomb.isCompromised(ctx)` → called by `SessionGate.allowTools()` on first gate pass.  
`Tamper.evaluate(ctx)` → contributes to `Guard.checkAndReport()`.

**Verification Tests:**
- Cert mismatch → `isCompromised()` returns true → BLOCKED ✓ (design verified)
- Debug flag → `Tamper.evaluate()` returns FLAG_DEBUGGABLE reason ✓
- Clone container path → detected via CLONE_FRAGS list ✓

---

## Layer 2 — Code, Resource & Symbol Protection

**Status: IMPLEMENTED**

### Components
- `proguard-rules.pro` — R8/ProGuard configuration
- `AndResGuard` plugin — Resource obfuscation
- `StrHide.kt` — XOR string obfuscation for sensitive strings
- `ProguardShield.kt` — Runtime keep-alive anchors
- CMake: `-fvisibility=hidden` on native symbols

### Implementation Details

**R8 Configuration:**
```
-optimizationpasses 7
-repackageclasses 'a'
-flattenpackagehierarchy 'a'
-overloadaggressively
-mergeinterfacesaggressively
```
All `Log.*` calls removed via `-assumenosideeffects`. Coroutine debug probes stripped. Source file attribute renamed to `SourceFile`.

**JNI/Reflection Keep Rules:**  
`sec.**`, `panel.**`, `AlvisiaApp`, `MainActivity`, `ToolCatalog`, `SubMenus`, `RamToolVault`, all native methods kept. Chaquopy bridge classes kept. Dynamic loading paths explicitly kept.

**String Obfuscation (StrHide):**  
`out[i] = data[i] XOR mask XOR (i AND 0x3F) XOR salt` — 3-operand XOR with index rotation. Applied to: API base URL, security path, all sensitive constant strings.

**Resource Protection:**  
AndResGuard renames resources to short identifiers (`arg`). Whitelist: ic_launcher, app_name, logo_alvisia, network_security_config.

**Native Symbol Visibility:**  
`-fvisibility=hidden` on CMake — only JNI exports are visible in the .so symbol table.

**Limitation:**  
`-Xno-call-assertions`, `-Xno-receiver-assertions`, `-Xno-param-assertions` remove Kotlin null checks in the compiled output — this is an intentional size/performance trade-off but reduces nullability enforcement at runtime.

---

## Layer 3 — Native Guard & JNI Protection

**Status: IMPLEMENTED + HARDENED (this session)**

### Components
- `rasp_guard.cpp` — Native RASP detection flags
- `NativeGuard.kt` — JNI bridge with input validation
- `NativeGate.kt` — Timing-based anti-debug, TracerPid double-read

### Implementation Details

**Native Detection Flags (8 bits):**
| Bit | Flag | Detects |
|-----|------|---------|
| 0x01 | FLAG_TRACER_PID | `/proc/self/status TracerPid > 0` |
| 0x02 | FLAG_MAPS_FRIDA | Frida/Xposed markers in `/proc/self/maps` |
| 0x04 | FLAG_PTRACE_ERROR | TracerPid re-check (ptrace fallback) |
| 0x08 | FLAG_HW_BREAKPOINT | Stubbed — returns 0 (timing side-channel used instead) |
| 0x10 | FLAG_INLINE_HOOK | strcmp prologue B/BL instruction check |
| 0x20 | FLAG_CAP_OVERGRANTED | CapEff == 0x3ffffffffffff |
| 0x40 | FLAG_SELF_HASH_BAD | FNV hash of own .so first 4KB vs baseline |
| 0x80 | FLAG_TIMING_PTRACE | 1000-iter loop > 5ms threshold |

**Self-Integrity Hash:**  
`__attribute__((constructor))` on_load() computes FNV hash of own .so's first 4KB. Runtime re-check detects in-memory patching of the native library.

**JNI Boundary Hardening (NEW — this session):**  
`decryptSealedPayload()` now validates:
- `buildId` format: `[A-Za-z0-9_\-.]` only, max 128 chars
- Payload hard size cap: 32MB (prevents OOM via malformed input)
- Both checks execute BEFORE `nativeSealSeed()` is called

**Kotlin Fallback:**  
When JNI unavailable (debug/CI): TracerPid file read + maps scan. Release builds throw on missing JNI.

**Open Item:**  
`FLAG_HW_BREAKPOINT` (bit 3) is stubbed at 0. Timing side-channel (bit 7) compensates. Hardware breakpoint detection via ARM64 MDSCR_EL1 is not implementable from userspace without kernel access.

---

## Layer 4 — Anti-Tamper & Integrity Monitor

**Status: IMPLEMENTED**

### Components
- `IntegrityBomb.kt` — APK/cert/DEX/clone detection
- `Tamper.kt` — Signing cert + debug flag checks
- `AssetVault.kt` — Asset integrity (AES-GCM auth tag is the integrity check)
- `LevelACore.kt` — HMAC-SHA512 over full bundle body

### Implementation Details

**Asset Integrity:**  
AES-GCM tag covers all asset bytes. Any modification invalidates the tag. No separate hash needed — authenticated decryption IS the integrity check.

**Bundle Integrity:**  
`LevelACore` applies HMAC-SHA512 over the full bundle body before 2-layer AES-GCM decryption. Forgery requires both the rootKey and the correct MAC.

**Anti-Clone:**  
`IntegrityBomb.evaluate()` checks data directory path for clone indicators. Repackaged APK with different package name → cert mismatch.

**Integration:**  
Integrity checks feed into `Guard.hostile()` and `SessionGate.allowTools()`. On compromise: `lock()` → `RamToolVault.wipeAll()`.

---

## Layer 5 — Runtime Defense & Dual-VM-Style Execution

**Status: IMPLEMENTED**

### Components
- `RaspEngine.kt` — Periodic 8s/60s RASP scanning daemon
- `Guard.kt` — Aggregated hostility assessment
- `FridaProbe.kt` — Async Frida port scan + 8 sync signal types
- `EnvProbe.kt` — 13-category environment assessment
- `MemoryGuard.kt` — Memory dump tool detection
- `NetworkGuard.kt` — Proxy/VPN detection
- `RamToolVault.kt` — In-memory tool storage with native wipe
- `CoreSession.kt` — Secure temp materialization with content wipe

### Implementation Details

**Threat Tiers:**
- Hard threats (instant kill): Frida attach, hook detection, memory dump open, integrity failure, cert mismatch, clone container
- Soft threats (report only): Root, emulator, VPN, proxy, ADB

**Periodic Scanning:**  
8-second interval for fast checks (TracerPid, maps). 60-second deep scan (full flag set, port scan re-arm, anti-dump).

**Frida Detection (8 vectors):**  
Async port scan (27042–27045, 23946, 27047, 1234, 4444) + paths + maps markers + fd scan + smaps + Unix socket scan + TracerPid.

**"Dual-VM-Style" Isolation:**  
Architecture note: True instruction virtualization is not implemented (no VM interpreter for Kotlin bytecode). The implemented model uses:
- Sealed module loading (separate decryption context)
- In-memory-only tool blobs (`RamToolVault`)
- Trust-level separation: security classes are a distinct concern from tool logic
- `CoreSession` materialization: plaintext only ever exists as a temp file with secure wipe on completion

**Kill Logic:**  
`hardKillCount >= 3` → `Process.killProcess()`. On each hard threat: `RamToolVault.wipeAll()` + `SessionGate.onThreat()`.

---

## Layer 6 — Sealed Payload & Secure Module Loading

**Status: IMPLEMENTED + GRADLE-INTEGRATED (this session)**

### Components
- `sealed_loader.py` — Python MetaPathFinder for .alv modules
- `NativeGuard.decryptSealedPayload()` — Kotlin/native decryption bridge
- `tools/seal_python.py` — Build-time sealing tool
- `AssetVault.kt` — Sealed asset loading from `assets/nx/`
- `LevelACore.kt` — 2-layer bundle decryption
- `app/build.gradle.kts` — Gradle seal/restore task hooks (NEW)

### Implementation Details

**Python Module Sealing:**  
Format: `ALVSEAL2` (8 bytes) + nonce (12 bytes) + AES-GCM ciphertext  
Key derivation: `SHA-256(seed || cert_bytes || buildId.UTF8)`  
Seed: per-build 32-byte random from `ALVSIA_SEAL_SEED_HEX` env var (baked into native .so via CMake)  
AAD: magic bytes `ALVSEAL2`

**14 sealed modules:**  
alvsia_bridge_impl, alvsia_core, alvsia_ultimate, alvsia_features, lua_output_validator, lua_string_recover, lua_engine/{engine, decompiler53, bgmi, luajit_decompiler, container, detector, multi_format, vm_deobfuscator}

**Session Gate in Python:**  
`sealed_loader._valid_session()`: `ALVSIA_APK_SESSION==1` AND `ALVISIA_SESSION_TOKEN` is 64-hex-char. Bridge cannot load sealed modules without a valid session token from the Kotlin layer.

**Gradle Integration (NEW):**  
- `sealPython` task: runs before `compileReleaseKotlin` and `processReleaseAssets`
- `restorePython` task: runs after any release build (even on failure via `buildFinished` hook)
- Enforces `ALVSIA_SEAL_SEED_HEX` presence at configure time

**Asset Sealing (AssetVault):**  
Key: `SHA-256(packageName + "|" + certSHA256.lowercase() + "|ALV-ASSET-v1")`  
Cert fallback REMOVED (this session) — fails secure if signing cert unavailable.  
Always-replace on materialize: prevents same-size persistence attacks.

**Bundle Decryption (LevelACore):**  
2-layer AES-GCM: HKDF outer wrap + HKDF inner wrap + HMAC-SHA512 MAC + zlib decompress. rootKey hardcoded in Kotlin (not in native .so).

**Known Limitation:**  
Plaintext Python source files ship in the handoff ZIP. In production, `seal_python.py --seal` must run before Chaquopy packages the Python source into the APK. The Gradle task hooks ensure this happens automatically in CodeMagic CI builds that provide `ALVSIA_SEAL_SEED_HEX`.

---

## Layer 7 — Server Authorization & Session Security

**Status: IMPLEMENTED + HARDENED (this session)**

### Components
- `SessionGate.kt` — Keystore-encrypted session, HMAC strike counter
- `PanelClient.kt` — Certificate-pinned OkHttp client
- `Vault.kt` — XOR-obfuscated endpoint configuration
- `Crypto.kt` — AES-CBC transport + PoW solver
- `Hwid.kt` — Hardware-bound device fingerprint
- `ThreatReport.kt` — Fire-and-forget security event reporting
- `ToolEngine.kt` — Anti-replay operation sequence (NEW)

### Implementation Details

**Session Encryption:**  
AES-256-GCM via Android Keystore (alias `alvsia_sg_v3`). Hardware-backed on TEE/StrongBox devices. Ciphertext-only in SharedPreferences — raw token never persists in plaintext.

**Strike Counter Integrity:**  
HMAC-SHA256 over strike value using a separate Keystore key (`alvsia_sg_strike_hmac_v1`). Root-editing the SharedPreferences XML triggers `strike_tamper` block.

**Session TTL:** 12 hours. Maximum strikes before lockout: 2.

**HWID Binding:**  
`SHA-256("ALVSIA|" + Build.MODEL + "|" + Build.FINGERPRINT + "|" + androidId)` — server-side binding enforced by panel backend.

**OTP Verification:**  
Delegated to panel backend. Session token (64-hex-char) issued post-OTP, stored encrypted in Keystore session.

**Certificate Pinning:**  
SPKI SHA-256 pin: `sha256/5xvRl/EyzQlZHSgU5dDZKbqmr+rFywWYzvSEEmJgC+Q=` on `alvsiapro.cc.cd`. Release: pin failure = throw (no downgrade). Debug: unpinned fallback.

**Transport Encryption:**  
AES-CBC with `transportKey(nonceHex) = SHA-256("ALVSIA_V2|" + nonce_bytes)`. PoW challenge solver (up to 5M iterations). Safe arithmetic evaluator for mechanic challenge (no eval()).

**Race Condition Fix (NEW — this session):**  
`allowTools()` and `unlock()` now use `synchronized(this)` guard for `_appCtx` initialization, preventing a race where `sessionOk` reads a null application context.

**Anti-Replay Operation Grant (NEW — this session):**  
`ToolEngine` maintains a monotonic atomic sequence counter (`AtomicLong`). Each tool dispatch increments the counter and verifies it is strictly greater than the last grant for the current session token. Prevents operation replay within a session.

**Replay Resistance:**  
PoW challenges are single-use (server-side). Session tokens bound to HWID. Anti-replay sequence in ToolEngine prevents in-process grant replay.

**Backend Requirements (not in APK, must be implemented server-side):**  
- HWID validation on login and tool operation grant
- OTP single-use enforcement
- Session token issuance and revocation
- Operation grant authorization check
- Threat report receiver endpoint

---

## Unified Architecture

```
AlvisiaApp.onCreate()
    ├── Guard.checkAndReport()          [Layer 1, 5]
    ├── EnvProbe.report()               [Layer 5]
    ├── RaspEngine.start() — daemon     [Layer 5]
    └── Python.start()                  [Layer 6]

MainActivity login flow
    ├── Guard.checkAndReport(soft)      [Layer 1, 5]
    ├── PanelClient.login()             [Layer 7]
    ├── OTP verify
    ├── Guard.checkAndReport(hard)      [Layer 5]
    ├── IntegrityBomb.isCompromised()   [Layer 1, 4]
    └── SessionGate.unlock()            [Layer 7]

ToolEngine.run()/runSub()
    ├── SessionGate.allowTools()
    │   ├── NativeGuard load check      [Layer 3]
    │   ├── Guard.runtimeHostile()      [Layer 5]
    │   ├── NativeGate.preCheck()       [Layer 3]
    │   ├── Guard.hostile()             [Layer 5]
    │   ├── IntegrityBomb.isCompromised()[Layer 4]
    │   ├── strike counter integrity    [Layer 7]
    │   └── session TTL + credentials  [Layer 7]
    ├── Anti-replay opSeq check         [Layer 7 NEW]
    └── Python bridge → sealed modules  [Layer 6]

RaspEngine daemon (8s / 60s)
    ├── NativeGuard.scanFlags()         [Layer 3]
    ├── FridaProbe.signals()            [Layer 5]
    ├── MemoryGuard.scan()              [Layer 5]
    └── On hard threat:
        ├── RamToolVault.wipeAll()      [Layer 5]
        └── SessionGate.onThreat()      [Layer 7]
```

---

## Changes Made in This Session

| File | Change | Layer |
|------|--------|-------|
| `AssetVault.kt` | Removed hardcoded cert fallback → fail-secure | 1, 6 |
| `NativeGuard.kt` | Added buildId format validation + 32MB payload cap | 3 |
| `SessionGate.kt` | Added synchronized(this) guard for _appCtx race condition | 7 |
| `ToolEngine.kt` | Added monotonic anti-replay sequence counter | 7 |
| `app/build.gradle.kts` | Added sealPython/restorePython Gradle tasks wired to release build | 6 |

---

## Open Items & Known Limitations

| Item | Severity | Notes |
|------|----------|-------|
| FLAG_HW_BREAKPOINT (bit 3) stubbed | Low | ARM64 MDSCR_EL1 not accessible from userspace. Timing check (bit 7) compensates. |
| Single SPKI cert pin | Medium | If cert rotates, app breaks. Add backup pin before broad release. |
| ZUC cipher approximation in decrypt_auto | Low | Tool 13 (Decrypt Engine) uses an approximation. Document limitation. |
| Frida Tracer generates scripts only (no live spawn) | Low | Tool 11 is a script generator; actual Frida invocation requires device-side Frida. |
| Python sealing requires separate env var in local builds | Info | CI/CodeMagic sets ALVSIA_SEAL_SEED_HEX automatically. Local release builds need manual export. |
| Backend server-side HWID/OTP enforcement not audited | Info | Out of scope — no backend source available. |
| -Xno-param-assertions removes Kotlin null checks | Low | Intentional trade-off; nullability must be maintained by design. |


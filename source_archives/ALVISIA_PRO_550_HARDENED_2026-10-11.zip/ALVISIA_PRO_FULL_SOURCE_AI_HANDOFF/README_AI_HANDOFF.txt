ALVISIA PRO - SOURCE HANDOFF

Start here:
1. Read AI_TASK_PROMPT.txt.
2. Read SOURCE_LINKS.txt.
3. Audit the complete source before editing.
4. Preserve all existing functionality.
5. Return changes, tests, build evidence and limitations.

Repository:
https://github.com/ALVISIA8/alvsia-pro-550

Inspect this ZIP for secrets before uploading it to another service.
Never include a release keystore, private key, password or access token.
